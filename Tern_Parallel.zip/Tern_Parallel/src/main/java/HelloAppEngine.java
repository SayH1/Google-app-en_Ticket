import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.FilterOperator;

@WebServlet(name = "HelloAppEngine", urlPatterns = { "/hello" })
public class HelloAppEngine extends HttpServlet {
	DatastoreService db = DatastoreServiceFactory.getDatastoreService();
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
//		Entity user = new Entity("User");
//		user.setProperty("user", "client");
//		user.setProperty("pass", "client");
//		user.setProperty("type", "client");
//		db.put(user);
		
		Query q = new Query("User").addFilter("user", FilterOperator.EQUAL, "").addFilter("pass", FilterOperator.EQUAL, "");
		PreparedQuery pq = db.prepare(q);
		pq.asSingleEntity();
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");

		response.getWriter().print("Hello App Engine!\r\n");

	}
}