import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.datastore.DatastoreService;
import com.google.appengine.api.datastore.DatastoreServiceFactory;
import com.google.appengine.api.datastore.Entity;
import com.google.appengine.api.datastore.PreparedQuery;
import com.google.appengine.api.datastore.Query;
import com.google.appengine.api.datastore.Query.FilterOperator;

@WebServlet(name = "login", urlPatterns = { "/login" })
public class login extends HttpServlet {
	DatastoreService db = DatastoreServiceFactory.getDatastoreService();
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String user=request.getParameter("user"),pass=request.getParameter("pass");
		if(user!=null && pass!=null) {
			Query q = new Query("User").addFilter("user", FilterOperator.EQUAL, user).addFilter("pass", FilterOperator.EQUAL, pass);
			PreparedQuery pq = db.prepare(q); 
			Entity loginuser  =pq.asSingleEntity();
			if(loginuser==null) {
				response.sendRedirect("index.jsp?status=unsuccess");
			}else {
				String type = (String) loginuser.getProperty("type");
				request.getSession(true);
				request.getSession().setAttribute("type", type );
				request.getSession().setAttribute("authen", loginuser.getKey().getName());
				if(type.equals("admin")) {
					response.sendRedirect("admin.jsp");
				}else {
					response.sendRedirect("home.jsp");
				}
			}
			

		}
	}
}